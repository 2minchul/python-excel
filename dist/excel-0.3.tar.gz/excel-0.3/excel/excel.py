#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import openpyxl
import xlrd
import os

try:
    from .exceptions import *
except:
    from exceptions import * 


def Excel(filename = '', mode = 'r'):
    if filename:
        ext = os.path.splitext(filename)[-1]
        if ext == '.xls':
            pass
        elif ext != '.xlsx':
            raise ReadError(filename)

    return XlsxController(filename, mode)

class XlsxCell:
    def __init__(self, cell):
        self.cell = cell
        self.col_idx = cell.col_idx
        self.value = cell.value
    
    def __str__(self):
        return self.cell.__str__()
    
    def __repr__(self):
        return self.cell.__repr__()
    


class XlsxController:
    def __init__(self, filename = '', mode = 'r'):
        self.filename = filename
        self.mode = mode
        
        if filename:
            self.load(filename)
        else:
            self.wb = openpyxl.Workbook()
            self.ws = self.wb.active
        
        self.max_row = self.height = self.ws.max_row
        self.max_col = self.width = self.ws.max_column
    
    def load(self, filename):
        try:
            self.wb = openpyxl.load_workbook(filename)
            self.ws = self.wb.active
        except:
            return False
        else:
            return True
    
    def save(self, filename):
        self.wb.save(filename)
    
    def get_row(self, row_n = 0):
        return tuple(XlsxCell(cell) for cell in self.ws[str(row_n+1)])
    
    def get_col(self, col_n = 0):
        return tuple(XlsxCell(cell) for cell in self.ws[self._num2col(col_n + 1)])
    
    
    def _num2col(self, col):
        return openpyxl.cell.cell.get_column_letter(col)
    
    def __enter__(self):
        return self
    
    def __exit__(self):
        if self.mode == 'w' and self.filename:
            self.save(self.filename)
        
        del self.ws
        self.wb.close()

if __name__ == '__main__':
    s = Excel('헤렌통합양식-20170524010208.xlsx')
    print(s.get_col(0))
    
    